#include <stdint.h>

#define RCC_AHB1ENR (*(volatile uint32_t*)0x40023830)
#define RCC_APB1ENR (*(volatile uint32_t*)0x40023840)

#define GPIOA_MODER (*(volatile uint32_t*)0x40020000)
#define GPIOA_AFRL  (*(volatile uint32_t*)0x40020020)

#define TIM3_PSC (*(volatile uint32_t*)0x40000428)
#define TIM3_ARR (*(volatile uint32_t*)0x4000042C)
#define TIM3_CCR1 (*(volatile uint32_t*)0x40000434)
#define TIM3_CCMR1 (*(volatile uint32_t*)0x40000418)
#define TIM3_CCER (*(volatile uint32_t*)0x40000420)
#define TIM3_CR1 (*(volatile uint32_t*)0x40000400)

void PWM_Init()
{

    RCC_AHB1ENR |= (1 << 0);
    RCC_APB1ENR |= (1 << 1);


    GPIOA_MODER &= ~(3 << (6 * 2));
    GPIOA_MODER |= (2 << (6 * 2));


    GPIOA_AFRL |= (2 << (6 * 4));


    TIM3_PSC = 16 - 1;
    TIM3_ARR = 20000 - 1;

    // PWM mode
    TIM3_CCMR1 |= (6 << 4);
    TIM3_CCMR1 |= (1 << 3);

    TIM3_CCER |= (1 << 0);

    TIM3_CR1 |= (1 << 7);
    TIM3_CR1 |= (1 << 0);
}

void Servo_SetAngle(uint8_t angle)
{

    uint16_t pulse = 1000 + ((angle * 1000) / 180);

    TIM3_CCR1 = pulse;
}

int main()
{
    PWM_Init();

    while (1)
    {
        Servo_SetAngle(0);
        for (volatile int i=0;i<300000;i++);

        Servo_SetAngle(90);
        for (volatile int i=0;i<300000;i++);

        Servo_SetAngle(180);
        for (volatile int i=0;i<300000;i++);
    }
}
